function setup() {
  createCanvas(400, 300);
  print("hello")
}

function draw() {
  background(100);
  
  // line(0,50,400,300);

  rectMode(CENTER);
  
  //this is the blue rectangle in the center
  
  fill(0,0,255)
  stroke(0,255,0);
  strokeWeight(4);
  rect(200 ,150, 150, 150);
  // Red cricle
  // later i went to make this circle
  
  fill(255,0,0,175);
  noStroke();
  ellipse(150,250,100,75);
  
  
  
  
  
}