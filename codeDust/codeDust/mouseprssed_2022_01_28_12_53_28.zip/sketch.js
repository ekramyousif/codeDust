//code 

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(200,50,60);
  
  
  noStroke();
  fill(0,255,50);
  circle(mouseX,mouseX,60);
  
}
function mouseprssed () {
  background(0);
  
}