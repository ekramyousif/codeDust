function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220,0,200);
  line(0,0,400,300)
  rectMode(CENTER)
  rect(200,150,150,150)
}