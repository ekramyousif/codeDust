//qustion:1
//Try changing the number on the "createcanva"and "background"
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220, 55, 150);
  triangle(30, 30, 180, 130 ,250, 50);
  fill(78,66,22);
  ellipse(100,200,100);
  fill(600)
  
  
  }