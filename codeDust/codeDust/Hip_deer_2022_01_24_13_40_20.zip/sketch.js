function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(20,60,300)
  ellipse(200,110,200)
  fill(5);
  rect(10,250,150,100)
  fill(500)
}